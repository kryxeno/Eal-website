new Twitch.Embed("twitch-embed", {
    width: 854,
    height: 480,
    channel: "EAL_Esports"
  });